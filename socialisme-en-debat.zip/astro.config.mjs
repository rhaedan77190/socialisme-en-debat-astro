import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

export default defineConfig({
  site: 'https://socialisme-en-debat.example', // ← remplace par ton domaine
  integrations: [
    tailwind({
      config: { applyBaseStyles: false }
    })
  ],
  server: { port: 4321 }
});