---
title: "Nikolaï Boukharine : points de repère"
description: "Repères rapides pour situer Boukharine dans le paysage intellectuel et politique."
date: 2025-08-03
tags: ["URSS", "Boukharine", "histoire"]
---

## Pourquoi Boukharine compte

Entre théorie économique, débats sur la NEP et tragédie politique, Boukharine condense un siècle de tensions.

## Trois lignes de force

1. **Économie** — la croissance « à pas de tortue » vs. industrialisation accélérée.  
2. **Politique** — la coalition et ses limites.  
3. **Biographie** — l'intellectuel, le militant, l'accusé.

## À lire ensuite

- Articles des années 1920.  
- Procès et réhabilitations.  
- Réceptions contemporaines.