---
title: "Lectures — Semaine 32"
description: "Notes de lecture et liens commentés."
date: 2025-08-05
tags: ["lectures", "bibliographie"]
---

## Sur la table

- Essais d'histoire économique.
- Un débat sur les coalitions.
- Archives numérisées.

## Notes rapides

La nuance n'est pas l'ennemie de la conviction. Elle en est la méthode.