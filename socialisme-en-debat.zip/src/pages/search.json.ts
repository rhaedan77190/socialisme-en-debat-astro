import { getCollection } from 'astro:content';

export async function GET() {
  const posts = await getCollection('blog', ({ data }) => !data.draft);
  const items = posts.map((p) => ({
    title: p.data.title,
    description: p.data.description ?? '',
    tags: p.data.tags ?? [],
    date: p.data.date,
    slug: p.slug,
    url: `/blog/${p.slug}/`,
    content: p.body?.slice(0, 8000) ?? ''
  }));
  return new Response(JSON.stringify(items), {
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'public, max-age=3600'
    }
  });
}