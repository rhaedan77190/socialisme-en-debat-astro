import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

export default defineConfig({
  // URL du site utilisé pour générer des liens absolus (RSS, metadata). Ici on pointe vers le domaine GitHub Pages.
  site: 'https://rhaedan77190.github.io/socialisme-en-debat-astro',
  // Base path pour les assets et le routing lors du déploiement sur GitHub Pages.
  // Sans cette option, Astro génère des liens absolus depuis la racine du domaine, ce qui casse les CSS/JS.
  base: '/socialisme-en-debat-astro/',
  integrations: [
    tailwind({
      config: { applyBaseStyles: false }
    })
  ],
  server: { port: 4321 }
});