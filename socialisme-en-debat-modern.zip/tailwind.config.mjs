/** @type {import('tailwindcss').Config} */
import typography from '@tailwindcss/typography';

export default {
  darkMode: 'class',
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,ts,tsx,vue,svelte}'],
  theme: {
    extend: {
      /**
       * Colour palette
       *
       * The design for the refreshed blog embraces a modern, minimal look.  Neutral
       * backgrounds keep the focus on the content, while a single bold accent
       * colour (brand) is used for calls‑to‑action and highlights.  The paper
       * colour sits just off‑white to reduce glare, and ink is a dark grey for
       * comfortable reading.  A separate surface colour is provided for cards
       * and panels.
       */
      colors: {
        brand: {
          50: '#fff5f5',
          100: '#ffe8e8',
          200: '#fecaca',
          300: '#f19999',
          400: '#e86f6f',
          500: '#e23636',        // primary accent (unchanged for identity)
          600: '#c62020',
          700: '#a81515',
          800: '#7a1010',
          900: '#4a0a0a'
        },
        /**
         * Very light background used on the page body.  Slightly warmer than pure
         * white to reduce eye strain.
         */
        paper: '#F9F9F7',
        /**
         * Default text colour for paragraphs.  A dark grey instead of pure
         * black improves contrast without overwhelming.
         */
        ink: '#1F2937',
        /**
         * Secondary highlight used occasionally for subtle accents.  We keep
         * ocre for small touches on diagrams or quotes.
         */
        ocre: '#C9A227',
        /**
         * Surface colour used for cards and panels in light mode.  In dark
         * mode the default Tailwind neutral palette is used instead.
         */
        surface: '#FFFFFF'
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'Avenir', 'Helvetica', 'Arial', 'sans-serif'],
        serif: ['"Source Serif 4"', 'Georgia', 'Cambria', 'Times New Roman', 'serif'],
        mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace']
      }
    }
  },
  plugins: [typography]
};