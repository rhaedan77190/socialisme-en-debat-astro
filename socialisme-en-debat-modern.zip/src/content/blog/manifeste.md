---
title: "Manifeste éditorial"
description: "Pourquoi ce blog, et comment lire les textes."
date: 2025-08-01
tags: ["méthode", "éditorial"]
---

## Ce que tu trouveras ici

Des textes qui privilégient **la clarté** sur le slogan. On prend le temps d'expliquer, de citer, de douter.

### Format

- Des analyses longues.
- Des notes courtes.
- Des dossiers thématiques avec bibliographies.

## Principes

1. **Transparence des sources.**
2. **Précision des concepts.**
3. **Droit au contre-argument.**

> Lire, contester, clarifier — le triptyque maison.