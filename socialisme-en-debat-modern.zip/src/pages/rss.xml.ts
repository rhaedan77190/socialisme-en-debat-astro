import rss from '@astrojs/rss';
import { getCollection } from 'astro:content';

export async function GET(context) {
  const posts = await getCollection('blog', ({ data }) => !data.draft);
  return rss({
    title: 'Socialisme en débat',
    description: 'Analyses, histoire, débats.',
    site: context.site ?? new URL('http://localhost:4321'),
    items: posts
      .sort((a,b) => +new Date(b.data.date) - +new Date(a.data.date))
      .map((p) => ({
        title: p.data.title,
        description: p.data.description,
        pubDate: p.data.date,
        link: `/blog/${p.slug}/`
      }))
  });
}